<?php

require_once "../incl/session.inc.php";

if (strlen($_SESSION['student']) > 0) {

    header("location:../index.php");
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0,
          maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Registration</title>
</head>
<body style="text-align: center">

<div class="container-lg">

<h2>Student Toevoegen</h2>

<form action="newstudent_verwerk.php" method="post">

    <p>
        <label for="studentnummer">studentnummer:</label><br>
        <input type="number" id="studentnummer" name="studentnummer" required>
    </p>

    <p>
        <label for="voornaam">voornaam:</label><br>
        <input type="text" name="voornaam" id="voornaam" required>
    </p>

    <p>
        <label for="tussenvoegsel">tussenvoegsel:</label><br>
        <input type="text" name="tussenvoegsel" id="tussenvoegsel">
    </p>

    <p>
        <label for="achternaam">achternaam:</label><br>
        <input type="text" name="achternaam" id="achternaam" required>
    </p>

    <p>
        <label for="klas">klas: </label>
        <select id="klas" name="klas">
            <option value="i1a">i1a</option>
            <option value="i1b">i1b</option>
            <option value="i1c">i1c</option>
        </select>
    </p>

    <p>
        <label for="email">email:</label><br>
        <input type="text" name="email" id="email" required>
    </p>

    <p>
        <label for="wachtwoord">wachtwoord:</label><br>
        <input type="password" name="wachtwoord" id="wachtwoord" required>
    </p>

    <p>
        <button onclick="history.back();return false;">Annuleren</button>
        <input type="submit" name="submit" id="submit" value="Aanmaken">
    </p>

</form>

</div>
</body>
</html>

