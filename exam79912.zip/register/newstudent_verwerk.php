<?php

require '../incl/config.php';

$studentnummer  = $_POST['studentnummer'];
$klas           = $_POST['klas'];
$voornaam       = $_POST['voornaam'];
$tussenvoegsel  = $_POST['tussenvoegsel'];
$achternaam     = $_POST['achternaam'];
$email          = filter_var($_POST["email"], FILTER_SANITIZE_EMAIL);
$wachtwoord     = $_POST['wachtwoord'];
$wachtwoord     = md5($wachtwoord);

// INSTERT INTO DATABASE
$query = ("INSERT INTO student (studentnummer, klas, voornaam, tussenvoegsel, achternaam, email, wachtwoord) VALUES ('$studentnummer', '$klas', '$voornaam', '$tussenvoegsel', '$achternaam', '$email', '$wachtwoord')");

$result = mysqli_query($mysqli, $query);

if ($result) {

    echo "new student aangemaakt";
    header( "refresh:2;url=../index.php" );
} else {

    echo "Er is een fout opgetreden";
    header( "refresh:2;url=../index.php" );
}