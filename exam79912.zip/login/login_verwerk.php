<?php

require_once '../incl/config.php';

$username       = $_POST['username'];
$wachtwoord     = $_POST['wachtwoord'];
$wachtwoord     = md5($wachtwoord);

//Alleen als het een studentnummer is moet hij deze code gebruiken
if (is_numeric($username)) {

    $query = ("SELECT * FROM student WHERE studentnummer = '$username' AND wachtwoord = '$wachtwoord'");

    $result = mysqli_query($mysqli, $query);

    //op correcte login start de session en sla de ID op
    if (mysqli_num_rows($result) == 1) {

        session_start();

        $_SESSION['student'] = $username;

        echo "U bent ingelogd!";

        header( "refresh:3;url=../index.php" );

    } else {

        //stuur terug als login niet correct is
        echo "Er was een fout bij het inloggen";
        header( "refresh:3;url=login.php" );

    }

} else {

    $query = "SELECT * FROM mentor WHERE email = '$username' AND wachtwoord = '$wachtwoord'";

    $result = mysqli_query($mysqli, $query);

    //op correcte login
    if (mysqli_num_rows($result) == 1)
    {

        //start session
        session_start();

        $_SESSION['mentor'] = $username;

        echo "U bent ingelogd!";

        header( "refresh:2;url=../index.php" );

    } else {

        echo "Er was een fout bij het inloggen";
        header( "refresh:2;url=login.php" );
    }

}