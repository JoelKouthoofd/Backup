<?php

require_once '../incl/session.inc.php';
require_once '../incl/config.php';

// Read ID from url
$studentnummer = $_GET['studentnummer'];

// Numeric ID & country check
if (is_numeric($studentnummer))
{

    $result = mysqli_query($mysqli, "DELETE FROM student WHERE studentnummer = $studentnummer");

    // If a member has been found
    if ($result)
    {

        echo "student succesful verwijderd!<br>";
        header( "refresh:2;url=../index.php" );

    } else {

        echo "Er is een fout opgetreden met het verwijderen";
        header( "refresh:2;url=../index.php" );

    }

} else {

    echo "Incorrect ID";
    header( "refresh:2;url=../index.php" );


}
