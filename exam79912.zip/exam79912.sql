-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 07, 2021 at 10:54 AM
-- Server version: 10.1.48-MariaDB-0ubuntu0.18.04.1
-- PHP Version: 7.1.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `exam79912`
--

-- --------------------------------------------------------

--
-- Table structure for table `beoordeling`
--

CREATE TABLE `beoordeling` (
  `id` int(11) NOT NULL,
  `studentnummer` int(10) NOT NULL,
  `begin` date NOT NULL,
  `eind` date NOT NULL,
  `bedrijf` varchar(255) NOT NULL,
  `adres` varchar(255) NOT NULL,
  `plaats` varchar(255) NOT NULL,
  `beoordeling1` int(1) NOT NULL,
  `beoordeling2` int(1) NOT NULL,
  `beoordeling3` int(1) NOT NULL,
  `beoordeling4` int(1) NOT NULL,
  `verslag` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `beoordeling`
--

INSERT INTO `beoordeling` (`id`, `studentnummer`, `begin`, `eind`, `bedrijf`, `adres`, `plaats`, `beoordeling1`, `beoordeling2`, `beoordeling3`, `beoordeling4`, `verslag`) VALUES
(2, 79912, '2021-07-06', '2021-07-16', '79912', '3020923dwfefa2', '79912', 1, 1, 1, 1, 'f  '),
(6, 79912, '2021-07-06', '2021-07-16', '79912', 'fweageg', '79912', 1, 1, 1, 1, 'f   '),
(7, 79912, '2021-07-06', '2021-07-16', '79912', '3020923dwfefa2', '79912', 1, 1, 1, 1, 'f  ');

-- --------------------------------------------------------

--
-- Table structure for table `mentor`
--

CREATE TABLE `mentor` (
  `id` int(10) NOT NULL,
  `email` varchar(255) NOT NULL,
  `wachtwoord` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mentor`
--

INSERT INTO `mentor` (`id`, `email`, `wachtwoord`) VALUES
(1, 'mentor@gmail.com', '23cbeacdea458e9ced9807d6cbe2f4d6');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `studentnummer` int(10) NOT NULL,
  `klas` varchar(5) NOT NULL,
  `voornaam` varchar(70) NOT NULL,
  `tussenvoegsel` varchar(70) NOT NULL,
  `achternaam` varchar(70) NOT NULL,
  `email` varchar(255) NOT NULL,
  `wachtwoord` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`studentnummer`, `klas`, `voornaam`, `tussenvoegsel`, `achternaam`, `email`, `wachtwoord`) VALUES
(10, 'i1a', 'yres', 'geen', 'kouthoofd', 'joel@gmail.com', 'd3d9446802a44259755d38e6d163e820'),
(79912, 'i1a', 'no', 'geen', 'kouthoofd', 'joel@gmail.com', '5c502d19e8aa6098a32d977ebd51f871');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `beoordeling`
--
ALTER TABLE `beoordeling`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mentor`
--
ALTER TABLE `mentor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`studentnummer`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `beoordeling`
--
ALTER TABLE `beoordeling`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `mentor`
--
ALTER TABLE `mentor`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
