<?php

require_once '../incl/session.inc.php';
require_once '../incl/config.php';

$studentnummer  = $_POST['studentnummer'];

if (strlen($_SESSION['mentor']) > 0) {

    $klas           = $_POST['klas'];
    $voornaam       = $_POST['voornaam'];
    $tussenvoegsel  = $_POST['tussenvoegsel'];
    $achternaam     = $_POST['achternaam'];
    $email          = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);


    $query = "UPDATE student SET klas = '$klas', voornaam = '$voornaam', tussenvoegsel = '$tussenvoegsel', achternaam = '$achternaam', email = '$email' WHERE studentnummer = '$studentnummer'";

    $result = mysqli_query($mysqli, $query);

    if ($result) {

        //Ga terug naar de home pagina als correct is gewijzigd
        echo "Update success!";
        header( "refresh:2;url=../index.php" );

    } else {

        echo "Er is een fout opgetreden.";
        header( "refresh:2;url=../index.php" );
    }
}