<?php

$db_hostname = 'localhost';
$db_username = 'master';
$db_password = 'master';
$db_database = 'exam79912';

$mysqli = mysqli_connect($db_hostname, $db_username, $db_password, $db_database);


if(!$mysqli){

    echo "Fout geen connectie naar database. <br>";
    echo "Errno: ". mysqli_connect_errno() . "<br>";
    echo "Error: ". mysqli_connect_error() . "<br>";

    exit;
}
else {


}