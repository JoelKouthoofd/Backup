<?php

require_once '../incl/session.inc.php';
require_once '../incl/config.php';

//lees studentnummer op
$id = $_GET['id'];

$result = mysqli_query($mysqli, "SELECT * FROM beoordeling WHERE id = $id");

if (mysqli_num_rows($result) == 1) {

    $row = mysqli_fetch_array($result);
} else {

    echo "geen beoordeling gevonden";
    header( "refresh:3;url=../index.php" );
}

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0,
          maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Land Registratie</title>
</head>
<body style="text-align: center">

<div class="container-lg">

    <h2>Student Bewerken</h2>

    <form action="beoordeling_bewerk_verwerk.php" method="post" enctype="multipart/form-data">

        <input type="hidden" id="id" name="id" value="<?php echo $id; ?>">

        <p>
            <label for="begin">Begindatum stage:</label><br>
            <input type="date" id="begin" name="begin" required
                   value="<?php echo $row['begin']; ?>">
        </p>

        <p>
            <label for="eind">Einddatum stage:</label><br>
            <input type="date" id="eind" name="eind" required
                   value="<?php echo $row['eind']; ?>">
        </p>

        <p>
            <label for="bedrijf">bedrijf:</label>
            <input type="text" name="bedrijf" id="bedrijf" required
                   value="<?php echo $row['bedrijf']; ?>">
        </p>

        <p>
            <label for="adres">adres:</label>
            <input type="text" name="adres" id="adres" required
                   value="<?php echo $row['adres']; ?>">
        </p>

        <p>
            <label for="plaats">plaats:</label>
            <input type="text" name="plaats" id="plaats" required
                   value="<?php echo $row['plaats']; ?>">
        </p>

        <p> Beoordeel van 1 tot 10</p>

        <p>
            <label for="beoordeling1">Begeleiding van de bedrijfsbegeleider: </label>
            <select id="beoordeling1" name="beoordeling1">
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
                <option value="9">9</option>
                <option value="10">10</option>
            </select>
        </p>

        <p>
            <label for="beoordeling2">Veel geleerd wat betreft programmeren: </label>
            <select id="beoordeling2" name="beoordeling2">
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
                <option value="9">9</option>
                <option value="10">10</option>
            </select>
        </p>

        <p>
            <label for="beoordeling3">Veel geleerd wat betreft werken in een bedrijf: </label>
            <select id="beoordeling3" name="beoordeling3">
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
                <option value="9">9</option>
                <option value="10">10</option>
            </select>
        </p>

        <p>
            <label for="beoordeling4">Wat vond je in totaal van het stagebedrijf: </label>
            <select id="beoordeling4" name="beoordeling4">
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
                <option value="9">9</option>
                <option value="10">10</option>
            </select>
        </p>

        <p>
            <label for="verslag">Kort verslagje over de ervaringen binnen het bedrijf (Wat ging goed, wat ging fout):</label><br>
            <textarea name="verslag" id="verslag" required><?php echo $row['verslag']; ?> </textarea>
        </p>

        <p>
            <button onclick="history.back();return false;">Annuleren</button>
            <input type="submit" name="submit" id="submit" value="Bewerken">
        </p>

    </form>

</div>
</body>
</html>
