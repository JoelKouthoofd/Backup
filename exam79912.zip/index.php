<?php

include "incl/config.php";
include "incl/session.inc.php";


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home pagina</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href="main.css" rel="stylesheet" type="text/css">
</head>
<body>

<div class="container-lg">

    <?php

        if (strlen($_SESSION['mentor']) > 0) {

            echo "U bent ingelogd als <strong>" . $_SESSION['mentor'] . "</strong><br>";
        }

        if (strlen($_SESSION['student']) > 0) {

            echo "U bent ingelogd als <strong>" . $_SESSION['student'] . "</strong><br>";
        }

    ?>

    <button type="button" class="btn btn-outline-secondary"    style="margin: 1.5rem 0rem 2.5rem 0rem" onclick="document.location = 'login/logout.php'">Uitloggen</button>

<!--    alleen laten zien aan docenten-->
    <?php if (strlen($_SESSION['mentor']) > 0) { ?>
    <button type="button" class="btn btn-outline-warning" style="margin: 1.5rem 0rem 2.5rem 0rem" onclick="document.location = 'register/newstudent.php'">Student Aanmaken</button>
    <?php } ?>

<!--    alleen laten zien aan studenten -->
    <?php if (strlen($_SESSION['student']) > 0) { ?>
    <button type="button" class="btn btn-outline-success" style="margin: 1.5rem 0rem 2.5rem 0rem" onclick="document.location = 'beoordeling/beoordeling.php'">beoordeling</button>
    <?php } ?>

    <h2>Overzicht studenten</h2>

    <?php

    //een query klaarzetten voor de lijst
    $result = mysqli_query($mysqli, "SELECT * FROM student ORDER BY studentnummer ASC");

    //maak een tabel aan
    echo "<table class='table table-dark'>";

    // Rij maken per land
    echo "<tr>";

    // echo "<th scope='col'><strong>#</strong></th>";
    echo "<th scope='col'>Studentnummer</th>";
    echo "<th scope='col'>Klas</th>";
    echo "<th scope='col'>Voornaam</th>";
    echo "<th scope='col'>Tussenvoegsel</th>";
    echo "<th scope='col'>achternaam</th>";
    echo "<th scope='col'>Emailadres</th>";

    if (strlen($_SESSION['mentor']) > 0) {

        echo "<th scope='col'></th>";
        echo "<th scope='col'></th>";
    }

    // Rij Afsluiten
    echo "</tr>";

    while ($row = mysqli_fetch_array($result)) {

        echo "<tr>";

        //Roep de gegevens van de tabellen op
        echo "<td><a href='beoordeling/student_beoordeling.php?studentnummer=" . $row['studentnummer'] . "'><em><strong>" . $row['studentnummer'] . "</strong></em></a>";
        echo "<td>" . $row['klas'] . "</td>";
        echo "<td>" . $row['voornaam'] . "</td>";
        echo "<td>" . $row['tussenvoegsel'] . "</td>";
        echo "<td>" . $row['achternaam'] . "</td>";
        echo "<td>" . $row['email'] . "</td>";

        if (strlen($_SESSION['mentor']) > 0) {

            //link bewerken en verwijderen aan studentnummer van de leerling
            echo "<td><a href='student/student_bewerk.php?studentnummer=" . $row['studentnummer'] . "'>Bewerken</a></td>";
            echo "<td><a href='student/student_verwijder.php?studentnummer=" . $row['studentnummer'] . "'>verwijderen</td>";
        }
    }

     echo "</tr>";

    ?>

</div>
</body>
</html>