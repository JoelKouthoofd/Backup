<?php

require_once '../incl/session.inc.php';
require_once '../incl/config.php';

//lees studentnummer op
$studentnummer = $_GET['studentnummer'];

$result = mysqli_query($mysqli, "SELECT * FROM student WHERE studentnummer = $studentnummer");

if (mysqli_num_rows($result) == 1) {

    $row = mysqli_fetch_array($result);
} else {

    echo "geen student gevonden";
    header( "refresh:3;url=../index.php" );
}

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0,
          maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Land Registratie</title>
</head>
<body style="text-align: center">

<div class="container-lg">

<h2>Student Bewerken</h2>

<form action="student_bewerk_verwerk.php" method="post" enctype="multipart/form-data">

    <input type="hidden" id="studentnummer" name="studentnummer" value="<?php echo $studentnummer; ?>">

    <p>
        <label for="Voornaam">Voornaam:</label><br>
        <input type="text" id="voornaam" name="voornaam" required
               value="<?php echo $row['voornaam']; ?>">
    </p>

    <p>
        <label for="tussenvoegsel">tussenvoegsel:</label><br>
        <input type="text" id="tussenvoegsel" name="tussenvoegsel" required
               value="<?php echo $row['tussenvoegsel']; ?>">
    </p>

    <p>
        <label for="achternaam">achternaam:</label>
        <input type="text" name="achternaam" id="achternaam" required
               value="<?php echo $row['achternaam']; ?>">
    </p>

    <p>
        <label for="klas">klas:</label>
        <select id="klas" name="klas">
            <option value="i1a">i1a</option>
            <option value="i1b">i1b</option>
            <option value="i1c">i1c</option>
        </select>
    </p>

    <p>
        <label for="email">emailadres:</label>
        <input type="text" name="email" id="email" required
               value="<?php echo $row['email']; ?>">
    </p>

    <p>
        <button onclick="history.back();return false;">Annuleren</button>
        <input type="submit" name="submit" id="submit" value="Register">
    </p>

</form>

</div>
</body>
</html>
