<?php

require_once '../incl/config.php'

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Log-in</title>
</head>
<body style="text-align: center; background-color: lightskyblue; margin-top: 10%;">

<div class="container-lg">

<h2>Inloggen</h2>

<form action="login_verwerk.php" method="post">

    <p>
        <label for="username">Username:</label><br>
        <input type="text" name="username" id="username" required>
    </p>

    <p>
        <label for="wachtwoord">Wachtwoord:</label><br>
        <input type="password" name="wachtwoord" id="wachtwoord" required>
    </p>

    <p>
        <button onclick="history.back();return false;">Annuleren</button>
        <input type="submit" name="submit" id="submit" value="Inloggen">
    </p>

</form>

</div>
</body>
</html>
