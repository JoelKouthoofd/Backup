<?php

require_once '../incl/session.inc.php';
require_once '../incl/config.php';

//lezen van url
$studentnummer = $_GET['studentnummer'];

//check of het een leerlingnummer is
if (is_numeric($studentnummer)) {

    $result = mysqli_query($mysqli, "SELECT * FROM student WHERE studentnummer = $studentnummer
    ");

    //als een leerling gevonden is
    if (mysqli_num_rows($result) == 1) {

        $row = mysqli_fetch_array($result);
    } else {

        echo "student niet gevonden";
        header( "refresh:3;url=../index.php" );
    }
} else {

    echo "incorrect studentnummer";
    header( "refresh:3;url=../index.php" );

}

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Student Verwijderen</title>
</head>
<body>

<div class="container-lg">

<p>
    Weet je zeker dat je de student
    <strong><?php echo $row['voornaam']; ?></strong>
    Wilt verwijderen?
</p>

<p>
    <a href="student_verwijder_verwerk.php?studentnummer=<?php echo $studentnummer; ?>">Verwijder student</a>
</p>

<p>
    <a href="../index.php">Nee, Terug naar het overzicht</a>
</p>

</div>

</body>
</html>

