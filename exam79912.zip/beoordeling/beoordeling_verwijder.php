<?php

require_once '../incl/session.inc.php';
require_once '../incl/config.php';

//lezen van url
$id = $_GET['id'];

//check of het een id is
if (is_numeric($id)) {

    $result = mysqli_query($mysqli, "SELECT * FROM beoordeling WHERE id = $id");

    //als een leerling gevonden is
    if (mysqli_num_rows($result) == 1) {

        $row = mysqli_fetch_array($result);
    } else {

        echo "beoordeling niet gevonden";
        header( "refresh:3;url=../index.php" );
    }
} else {

    echo "incorrecte beoordeling";
    header( "refresh:3;url=../index.php" );

}

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>beoordeling Verwijderen</title>
</head>
<body>

<div class="container-lg">

    <p>
        Weet je zeker dat je de beoordeling voor
        <strong><?php echo $row['bedrijf']; ?></strong>
        Wilt verwijderen?
    </p>

    <p>
        <a href="beoordeling_verwijder_verwerk.php?id=<?php echo $id; ?>">Verwijder beoordeling</a>
    </p>

    <p>
        <a href="../index.php">Nee, Terug naar het overzicht</a>
    </p>

</div>

</body>
</html>

