<?php

require_once '../incl/session.inc.php';
require_once '../incl/config.php';



if ($_SESSION['student'] > 0) {

    $begin          = $_POST['begin'];
    $eind           = $_POST['eind'];
    $bedrijf        = $_POST['bedrijf'];
    $adres          = $_POST['adres'];
    $plaats         = $_POST['plaats'];
    $beoordeling1   = $_POST['beoordeling1'];
    $beoordeling2   = $_POST['beoordeling2'];
    $beoordeling3   = $_POST['beoordeling3'];
    $beoordeling4   = $_POST['beoordeling4'];
    $verslag        = $_POST['verslag'];
    $id = $_POST['id'];


    $query = "UPDATE beoordeling SET begin = '$begin', eind = '$eind', bedrijf = '$bedrijf', adres = '$adres',plaats = '$plaats', beoordeling1 = '$beoordeling1', beoordeling2 = '$beoordeling2', beoordeling3 = '$beoordeling3', beoordeling4 = '$beoordeling4', verslag = '$verslag' WHERE id = '$id'";

    $result = mysqli_query($mysqli, $query);

    if ($result) {

        //Ga terug naar de home pagina als correct is gewijzigd
        echo "Update success!";
        header( "refresh:2;url=../index.php" );

    } else {

        echo "Er is een fout opgetreden.";
        header( "refresh:2;url=../index.php" );
    }
}