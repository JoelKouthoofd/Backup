<?php

session_start();
require_once "config.php";

if (isset($_SESSION['mentor']) == 0 && isset($_SESSION['student']) == 0)
{
    //Niet ingelogd? stuur terug naar login
    header("Location:../login/login.php");

}