<?php

require_once "../incl/config.php";
require_once "../incl/session.inc.php";

?>

<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <title>Home pagina</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href="../main.css" rel="stylesheet" type="text/css">
</head>
<body>

<div class="container-lg">

<h2 style="margin: 50px 0px;">Beoordeling Student <em style="color: red"><?php echo $title = $_GET['studentnummer']; ?></em> </h2>

    <div class="row">
    <?php

    $studentnummer = $_GET['studentnummer'];

    $result = mysqli_query($mysqli, "SELECT * FROM beoordeling WHERE studentnummer = $studentnummer");

    while ($row = mysqli_fetch_array($result)) {

            echo "<div class='col-sm'>";
            echo "<div class='card' style='width: 26rem'>";
            echo "<div class='card-body'>";

            echo "<h5 class='card-title'>beoordeling " . $row['bedrijf'] . "</h5>";

            //Alle informatie over de beoordeling
            echo "<p class='card-text'>";
            echo "begin stage: <strong>"    . $row['begin'] . "</strong><br>";
            echo "einde stage: <strong>"    . $row['eind'] . "</strong><br>";
            echo "adres bedrijf: <strong>"  . $row['adres'] . "</strong><br>";
            echo "plaats bedrijf: <strong>" . $row['plaats'] . "</strong><br><br>";

            //Beoordelingen
            echo "begeleiding van bedrijfsleider: <strong>"                 . $row['beoordeling1'] . "</strong><br>";
            echo "veel geleerd wat betreft programmeren: <strong>"          . $row['beoordeling2'] . "</strong><br>";
            echo "veel geleerd wat betreft werken in een bedrijf: <strong>" . $row['beoordeling3'] . "</strong><br>";
            echo "Wat vond je in totaal van het bedrijf: <strong>"          . $row['beoordeling4'] . "</strong><br><br>";

            //verslag extra ruimte geven
            echo "Kort verslag je over ervaring binnen het bedrijf: <br><strong>"    . $row['verslag'] . "</strong>";
            echo "</p>";

            //laat debewerk knop zien als het de juiste student is
            if ($_SESSION['student'] == $studentnummer) {

                echo "<a style='color: red;' class='card-link' href='beoordeling_bewerk.php?id=" . $row['id'] . "'>bewerken</a>";
            }

            //laat de verwijder knop zien als het een mentor is
            if (strlen($_SESSION['mentor']) > 0 ) {

                echo "<a style='color: red;' class='card-link' href='beoordeling_verwijder.php?id=" . $row['id'] . "'>verwijderen</a>";
            }

            echo "</div>";
            echo "</div>";
            echo "</div>";

        }

        ?>

    </div>

</div>
</body>
</html>

