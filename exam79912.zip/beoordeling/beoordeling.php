<?php

require_once "../incl/session.inc.php";

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0,
          maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Registration</title>
</head>
<body style="text-align: center">

<div class="container-lg">

<h2>beoordeling</h2>

<form action="beoordeling_verwerk.php" method="post">

    <p>
        <label for="begin">begindatum stage:</label><br>
        <input type="date" id="begin" name="begin" required>
    </p>

    <p>
        <label for="eind">einddatum stage:</label><br>
        <input type="date" name="eind" id="eind" required>
    </p>

    <p>
        <label for="bedrijf">bedrijf:</label><br>
        <input type="text" name="bedrijf" id="bedrijf">
    </p>

    <p>
        <label for="adres">adres:</label><br>
        <input type="text" name="adres" id="adres" required>
    </p>

    <p>
        <label for="plaats">plaats:</label><br>
        <input type="text" name="plaats" id="plaats" required>
    </p>

    <p> Beoordeel van 1 tot 10</p>

    <p>
        <label for="beoordeling1">Begeleiding van de bedrijfsbegeleider: </label>
        <select id="beoordeling1" name="beoordeling1">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10</option>
        </select>
    </p>

    <p>
        <label for="beoordeling2">Veel geleerd wat betreft programmeren: </label>
        <select id="beoordeling2" name="beoordeling2">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10</option>
        </select>
    </p>

    <p>
        <label for="beoordeling3">Veel geleerd wat betreft werken in een bedrijf: </label>
        <select id="beoordeling3" name="beoordeling3">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10</option>
        </select>
    </p>

    <p>
        <label for="beoordeling4">Wat vond je in totaal van het stagebedrijf: </label>
        <select id="beoordeling4" name="beoordeling4">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10</option>
        </select>
    </p>

    <p>
        <label for="verslag">Kort verslagje over de ervaringen binnen het bedrijf (Wat ging goed, wat ging fout):</label><br>
        <textarea name="verslag" id="verslag" required></textarea>
    </p>

    <p>
        <button onclick="history.back();return false;">Annuleren</button>
        <input type="submit" name="submit" id="submit" value="Aanmaken">
    </p>

</form>

</div>
</body>
</html>

