<?php

require '../incl/config.php';
require '../incl/session.inc.php';

$begin          = $_POST['begin'];
$eind           = $_POST['eind'];
$bedrijf        = $_POST['bedrijf'];
$adres          = $_POST['adres'];
$plaats         = $_POST['plaats'];
$beoordeling1   = $_POST['beoordeling1'];
$beoordeling2   = $_POST['beoordeling2'];
$beoordeling3   = $_POST['beoordeling3'];
$beoordeling4   = $_POST['beoordeling4'];
$verslag        = $_POST['verslag'];
$studentnummer  = $_SESSION['student'];

if (strlen($_SESSION['student']) > 0) {

    // INSTERT INTO DATABASE
    $query = ("INSERT INTO beoordeling (studentnummer, begin, eind, bedrijf, adres, plaats, beoordeling1, beoordeling2, beoordeling3, beoordeling4, verslag) VALUES ('$studentnummer', '$begin', '$eind', '$bedrijf', '$adres', '$plaats', '$beoordeling1', '$beoordeling2', '$beoordeling3', '$beoordeling4', '$verslag')");

    $result = mysqli_query($mysqli, $query);

    if ($result) {

        echo "nieuwe beoordeling aangemaakt";
        header( "refresh:2;url=../index.php" );
    } else {

        echo "Er is een fout opgetreden";
        header( "refresh:2;url=../index.php" );
    }
}
